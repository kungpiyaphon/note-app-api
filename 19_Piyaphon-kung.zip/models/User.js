import { Schema, model } from "mongoose";

// Create MongoDB document schema
const UserSchema = new Schema({
  name: { type: String },
  username: { type: String, minlength: 3, maxlength: 30, unique: true, required: true },
  password: { type: String, minlength: 6, require: true },
  email: { type: String },
  createdOn: { type: Date, default: new Date().getTime() },
});

// Use schema to create model
// Mongoose will use model nam User and name our collection as users automaticcally
export const User = model("User", UserSchema);
